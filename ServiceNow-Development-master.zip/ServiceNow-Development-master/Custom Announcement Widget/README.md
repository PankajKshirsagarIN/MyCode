# Custom Floating Announcement
![Alt Text](https://github.com/Decoder-Paul/ServiceNow-Development/blob/master/Custom%20Announcement%20Widget/announcement_snap.PNG)
