# Custom Audit Report - with Download option
The data is coming from a database view which is created by combination of other three tables.
The custom report is having different Coulmn names and filtered data which is not feasible with Servicenow reporting tool.
#### Custom Report UI Page
![Table UI Page](Report%20UI.jpg)