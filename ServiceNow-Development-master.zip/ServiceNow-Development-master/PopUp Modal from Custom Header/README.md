# Modal Pop-up from Header Menu Item
![Alt Text](https://github.com/Decoder-Paul/ServiceNow-Development/blob/df7699c8e425c4f8a8ac5ac8703a6304df510420/PopUp%20Modal%20from%20Custom%20Header/Popup%20Modal%20on%20Menu%20Item%20click.gif)
