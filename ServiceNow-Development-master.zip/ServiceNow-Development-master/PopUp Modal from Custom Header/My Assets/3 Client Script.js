api.controller=function() {
  /* widget controller */
  var c = this;
};