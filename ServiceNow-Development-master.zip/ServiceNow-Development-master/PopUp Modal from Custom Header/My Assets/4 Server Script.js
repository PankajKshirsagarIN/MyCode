(function() {
  data.clockOptions = {"table": 'alm_hardware',"title": 'Assigned Assets',"color": '#FF0000',"hide_footer": 'true',"filter": 'assigned_toDYNAMIC90d1921e5f510100a9ad2572f2b477fe', "sp_page": 'form',"list_page": 'list',"fields": 'asset_tag,serial_number,model,install_status,location',"o": 'sys_updated_on',"d": 'desc'};
})();