# Custom Filter using Content Block
This custom filter can be used along with other filter widget
#### Filter Widget
![Filter Widget](Filter%20Widget.PNG)
#### Dashboard
![Dashboard](Dashboard.PNG)