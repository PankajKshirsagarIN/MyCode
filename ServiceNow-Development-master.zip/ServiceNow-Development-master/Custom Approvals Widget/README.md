# Multi-Approval Widget
- One can approve or reject multiple items in a single shot, by selecting the checkboxes
- Catalog variables can also be found by clicking more details Toggler of RITM Approval record
- Change Request deatails can be seen in similar way for the respecting Change Approval record
![Widget Snap](/widget_picture.JPG)